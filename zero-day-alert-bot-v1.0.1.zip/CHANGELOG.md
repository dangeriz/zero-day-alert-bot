# Changelog

## [v1.0.1] - 2025-08-05
### Changed
- Minor bug fixes
- Performance tweaks for notifier failover
- Updated README and DEPLOYMENT_GUIDE
- Updated workflows documentation

## [v1.0.0] - 2025-08-05
### Added
- Initial complete release with:
  - Multi-channel alerts (Discord, Signal, Slack)
  - Failover logic
  - Render deployment (scheduled + manual test jobs)
  - GitHub Actions for badge & failure log
  - Log rotation
  - Full documentation
