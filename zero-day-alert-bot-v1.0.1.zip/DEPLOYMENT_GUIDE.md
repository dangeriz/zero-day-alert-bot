# Deployment Guide — v1.0.1 (WIP)

## 🚀 Quick Start
1. Clone repo:
   ```bash
   git clone https://github.com/dangeriz/zero-day-alert-bot.git
   cd zero-day-alert-bot
