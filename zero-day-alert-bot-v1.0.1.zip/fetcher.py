"""
fetcher.py
v1.0.1 (WIP)
Fetches articles from configured RSS feeds for zero-day vulnerabilities.
"""

import feedparser
from datetime import datetime, timezone

# List of RSS feeds (can be expanded)
RSS_FEEDS = [
    "https://feeds.feedburner.com/TheHackersNews",
    "https://www.bleepingcomputer.com/feed/",
    "https://www.cisa.gov/cybersecurity-advisories/all.xml",
    "https://www.securityweek.com/feed/",
    "https://www.darkreading.com/rss.xml"
]

def fetch_articles():
    """
    Fetch articles from all configured RSS feeds.
    Returns:
        list: List of dicts containing article data.
    """
    articles = []
    seen_links = set()

    for feed_url in RSS_FEEDS:
        try:
            feed = feedparser.parse(feed_url)
        except Exception as e:
            print(f"⚠️ Failed to fetch from {feed_url}: {e}")
            continue

        for entry in feed.entries:
            link = entry.get("link")
            if link in seen_links:
                continue
            seen_links.add(link)

            articles.append({
                "title": entry.get("title", "No Title"),
                "link": link,
                "source": feed.feed.get("title", "Unknown Source"),
                "published": entry.get(
                    "published",
                    datetime.now(timezone.utc).isoformat()
                )
            })

    return articles
