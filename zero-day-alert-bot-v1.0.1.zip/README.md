# Zero-Day Alert Bot — v1.0.1 (WIP)

## 🚀 What’s New in v1.0.1
- Minor bug fixes
- Performance tweaks for notifier failover
- Updated README and DEPLOYMENT_GUIDE
- Updated workflows documentation

## 📜 Description
Multi-channel zero-day vulnerability alert bot with:
- Discord, Signal, and Slack notifications
- Failover (failure in one channel does not block others)
- Render deployment with both scheduled and manual test jobs
- GitHub Actions for alert badge and failure log pushes
- Log rotation (max 1000 lines)

## 🛠 Debug Logs
[📥 Download Latest Failure Log](https://github.com/dangeriz/zero-day-alert-bot/raw/main/notifications.log)  
*Note: This log is only updated if a notification channel fails.*

## 📜 Changelog
See [CHANGELOG.md](CHANGELOG.md) for a full list of updates and version history.
