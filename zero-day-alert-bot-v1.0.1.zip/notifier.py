"""
notifier.py
v1.0.1 (WIP)
Sends notifications to Discord, Signal, and Slack with failover.
Logs results to notifications.log with rotation (max 1000 lines).
Also triggers GitHub Actions for alert badge and failure log when needed.
"""

import os
import requests
from datetime import datetime, timezone

# ---- Notification Senders ----

def send_discord(articles):
    webhook = os.getenv("DISCORD_WEBHOOK_URL")
    if not webhook:
        return False
    try:
        for a in articles:
            payload = {
                "content": f"🛡️ **{a['title']}**\n🔗 {a['link']}\n📡 Source: {a['source']}"
            }
            requests.post(webhook, json=payload)
        return True
    except Exception as e:
        print(f"⚠️ Discord send failed: {e}")
        return False


def send_signal(articles):
    api_url = os.getenv("SIGNAL_API_URL")
    number = os.getenv("SIGNAL_NUMBER")
    recipient = os.getenv("SIGNAL_RECIPIENT")
    if not api_url or not number or not recipient:
        return False
    try:
        for a in articles:
            payload = {
                "number": number,
                "recipients": [recipient],
                "message": f"🛡️ {a['title']}\n🔗 {a['link']}\n📡 Source: {a['source']}"
            }
            requests.post(f"{api_url}/v2/send", json=payload)
        return True
    except Exception as e:
        print(f"⚠️ Signal send failed: {e}")
        return False


def send_slack(articles):
    webhook = os.getenv("SLACK_WEBHOOK_URL")
    if not webhook:
        return False
    try:
        for a in articles:
            payload = {
                "text": f"🛡️ *{a['title']}*\n🔗 {a['link']}\n📡 Source: {a['source']}"
            }
            requests.post(webhook, json=payload)
        return True
    except Exception as e:
        print(f"⚠️ Slack send failed: {e}")
        return False


# ---- Notification Orchestrator ----

def notify_all(articles):
    if not articles:
        print("No articles to send.")
        return {}

    status = {
        "discord": "✅ success" if send_discord(articles) else "⚠️ failed",
        "signal": "✅ success" if send_signal(articles) else "⚠️ failed",
        "slack": "✅ success" if send_slack(articles) else "⚠️ failed"
    }

    print("📢 Notification Status Report:")
    for ch, st in status.items():
        print(f" - {ch}: {st}")

    log_entry = f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} — " + \
                " | ".join([f"{ch.capitalize()}: {st}" for ch, st in status.items()])

    log_file = "notifications.log"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(log_entry + "\n")

    with open(log_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
    if len(lines) > 1000:
        with open(log_file, "w", encoding="utf-8") as f:
            f.writelines(lines[-1000:])

    trigger_github_actions(status)

    return status


# ---- GitHub Actions Trigger ----

def trigger_github_actions(status):
    repo = os.getenv("GITHUB_REPO")
    token = os.getenv("GITHUB_TOKEN")
    if not repo or not token:
        print("⚠️ Missing GitHub repo/token; skipping action triggers.")
        return

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}"
    }

    # Always trigger alert badge update
    try:
        requests.post(
            f"https://api.github.com/repos/{repo}/actions/workflows/update-alert-badge.yml/dispatches",
            headers=headers,
            json={"ref": "main"}
        )
        print("✅ Triggered update-alert-badge.yml")
    except Exception as e:
        print(f"⚠️ Failed to trigger update-alert-badge.yml: {e}")

    # Trigger failure log push if any channel failed
    if any(st == "⚠️ failed" for st in status.values()):
        try:
            requests.post(
                f"https://api.github.com/repos/{repo}/actions/workflows/push-failure-log.yml/dispatches",
                headers=headers,
                json={"ref": "main"}
            )
            print("✅ Triggered push-failure-log.yml")
        except Exception as e:
            print(f"⚠️ Failed to trigger push-failure-log.yml: {e}")
