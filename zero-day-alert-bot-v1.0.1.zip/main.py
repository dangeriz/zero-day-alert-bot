"""
main.py
v1.0.1 (WIP)
Main entry point for the Zero-Day Alert Bot.
"""

from fetcher import fetch_articles
from notifier import notify_all


def run_bot():
    """
    Fetches articles and sends notifications.
    """
    print("🔍 Fetching articles...")
    articles = fetch_articles()
    print(f"📄 {len(articles)} articles found.")

    if articles:
        notify_all(articles)
    else:
        print("⚠️ No new articles to notify.")


if __name__ == "__main__":
    run_bot()
