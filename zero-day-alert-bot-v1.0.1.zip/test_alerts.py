"""
test_alerts.py
v1.0.1 (WIP)
Sends a test alert to all channels: Discord, Signal, and Slack.
"""

from notifier import notify_all

sample_articles = [{
    "title": "🚨 Manual Test Alert",
    "link": "https://example.com/test",
    "source": "Manual Trigger"
}]

if __name__ == "__main__":
    notify_all(sample_articles)
