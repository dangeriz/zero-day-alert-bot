"""
signal_test.py
v1.0.1 (WIP)
Standalone script to test Signal notifications.
"""

import os
import requests
from dotenv import load_dotenv

load_dotenv()

SIGNAL_API_URL = os.getenv("SIGNAL_API_URL")
SIGNAL_NUMBER = os.getenv("SIGNAL_NUMBER")
SIGNAL_RECIPIENT = os.getenv("SIGNAL_RECIPIENT")

sample_articles = [{
    "title": "🚨 Signal Test Alert",
    "link": "https://example.com/test",
    "source": "Manual Trigger"
}]


def send_signal_test():
    if not SIGNAL_API_URL or not SIGNAL_NUMBER or not SIGNAL_RECIPIENT:
        print("⚠️ Missing Signal configuration in .env")
        return
    for a in sample_articles:
        payload = {
            "number": SIGNAL_NUMBER,
            "recipients": [SIGNAL_RECIPIENT],
            "message": f"🛡️ {a['title']}\n🔗 {a['link']}\n📡 Source: {a['source']}"
        }
        res = requests.post(f"{SIGNAL_API_URL}/v2/send", json=payload)
        print(f"Signal send status: {res.status_code}")


if __name__ == "__main__":
    send_signal_test()
