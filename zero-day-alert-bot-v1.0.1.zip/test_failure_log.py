"""
test_failure_log.py
v1.0.1 (WIP)
Appends a test failure entry to notifications.log and triggers the GitHub Action.
"""

import os
from datetime import datetime, timezone
from notifier import trigger_github_actions

log_file = "notifications.log"

test_status = {
    "discord": "⚠️ failed",
    "signal": "⚠️ failed",
    "slack": "⚠️ failed"
}

entry = f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} — [TEST ENTRY] " + \
        " | ".join([f"{ch.capitalize()}: {st}" for ch, st in test_status.items()])

with open(log_file, "a", encoding="utf-8") as f:
    f.write(entry + "\n")

print("✅ Added test failure log entry.")

trigger_github_actions(test_status)
