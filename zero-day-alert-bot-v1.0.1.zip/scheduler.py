"""
scheduler.py
v1.0.1 (WIP)
Schedules the main script to run at a fixed interval.
"""

import time
from main import run_bot


def run_scheduler(interval_hours=4):
    """
    Runs the bot every `interval_hours` hours.
    """
    while True:
        print(f"⏰ Running bot cycle...")
        run_bot()
        print(f"✅ Cycle complete. Sleeping for {interval_hours} hours.")
        time.sleep(interval_hours * 3600)


if __name__ == "__main__":
    run_scheduler()
